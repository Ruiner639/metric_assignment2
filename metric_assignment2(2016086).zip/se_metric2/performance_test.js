const { Builder } = require('selenium-webdriver')
const chrome = require('selenium-webdriver/chrome')
const fs = require('fs')

async function getPerformanceData() {
    let driver = await new Builder().forBrowser('chrome').build()
    await driver.get('https://en.wikipedia.org/wiki/Software_metric')
    await driver.sleep(5000)
    let data = await driver.executeScript("return window.performance.getEntries()")
    await driver.quit()
    return data
}

async function run() {
    let results = []
    for (let i = 0; i < 10; i++) {
        let data = await getPerformanceData()
        results.push(...data)
    }
    fs.writeFileSync('performance_data.json', JSON.stringify(results))
    let csv = 'name,duration\n' + results.map(d => `${d.name},${d.duration}`).join('\n')
    fs.writeFileSync('performance_data.csv', csv)
    let avg = results.reduce((sum, d) => sum + d.duration, 0) / results.length
    console.log('Avg duration:', avg.toFixed(2))
}

run()
